package com.airbnb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BnbApplicationTests {

	@Test
	void contextLoads() {
	}

}
